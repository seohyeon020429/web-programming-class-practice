require('dotenv').config();
const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'public/image'),
  filename: (req, file, cb) => cb(null, file.originalname)
});
const upload = multer({ storage: storage });

let db;
MongoClient.connect('mongodb+srv://seohyeonyun:hse09162%40@cluster0.mfh907u.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0').then((client) => {
  db = client.db('myboard');
  app.listen(8080, () => console.log('http://localhost:8080'));  
});

// Home
app.get('/', (req, res) => res.render('index'));

// 게시물 목록
app.get('/list', (req, res) => {
  db.collection('post').find().toArray().then((result) => {
    res.render('list', { data: result });
  });
});

// 게시물 저장
app.post('/save', (req, res) => {
  db.collection('post').insertOne({
    title: req.body.title,
    content: req.body.content,
    date: req.body.date,
    imagepath: req.body.imagepath || ''
  }).then(() => res.redirect('/list'));
});

// 게시물 작성 페이지
app.get('/enter', (req, res) => {
  res.render('enter');
});

// 게시물 상세보기
app.get('/content/:id', (req, res) => {
  db.collection('post').findOne({ _id: new ObjectId(req.params.id) }).then((result) => {
    res.render('content', { data: result });
  });
});

// 게시물 수정 페이지
app.get('/edit/:id', (req, res) => {
  db.collection('post').findOne({ _id: new ObjectId(req.params.id) }).then((result) => {
    res.render('edit', { data: result });
  });
});

// 게시물 수정 저장
app.post('/edit', (req, res) => {
  db.collection('post').updateOne(
    { _id: new ObjectId(req.body.id) },
    { $set: { title: req.body.title, content: req.body.content, date: req.body.date } }
  ).then(() => res.redirect('/list'));
});

// 게시물 삭제
app.post('/delete', (req, res) => {
  db.collection('post').deleteOne({ _id: new ObjectId(req.body._id) })
    .then(() => res.status(200).send('OK'));
});

// 이미지 업로드
app.post('/photo', upload.single('image'), (req, res) => {
  res.send({ imagePath: '/image/' + req.file.filename });
});

// 검색
app.get('/search', (req, res) => {
  db.collection('post').find({ title: { $regex: req.query.value, $options: 'i' } })
    .toArray().then((result) => {
      res.render('sresult', { data: result });
    });
});
